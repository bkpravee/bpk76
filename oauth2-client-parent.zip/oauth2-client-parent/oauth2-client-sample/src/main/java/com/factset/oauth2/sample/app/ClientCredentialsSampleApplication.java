package com.factset.oauth2.sample.app;


import java.io.File;
import java.io.IOException;
import java.net.URISyntaxException;
import java.nio.file.Paths;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.web.client.RestTemplate;

import com.factset.oauth2.client.sdk.service.OAuth2ClientCredentialsClientSDKService;
import com.nimbusds.jose.JOSEException;
import com.nimbusds.oauth2.sdk.ParseException;


public class ClientCredentialsSampleApplication {
	private static final Logger logger = LoggerFactory.getLogger(ClientCredentialsSampleApplication.class);

	public static void main(String[] args) throws ParseException, java.text.ParseException, URISyntaxException, JOSEException, IOException {
		System.out.println("####---Running Client Credentials OAuth client sample--####");
		commandLineTestSuiteRun(args);
	}
	
	private static void commandLineTestSuiteRun(String[] args) throws ParseException, java.text.ParseException, URISyntaxException, JOSEException, IOException {
		//first read from environment variables
		String clientMetadataPath = System.getenv("oauth2.client.file.path");
		boolean isEnvConfigured = true;
		//STEP-1: read download client JSON, set environment variable and validate the path
		if (StringUtils.isBlank(clientMetadataPath)) {
			if (args == null || args.length == 0) {
				System.err.println("ERROR ---Metadata path should be provided via environment variable or command line Arugment---");
				System.exit(0);
			}
			//If no env variable found look for metadata from command line argument
			clientMetadataPath = args[0];
			if (StringUtils.isBlank(clientMetadataPath)){
				System.err.println("ERROR ---Metadata path arugment is incorrect from command line---");
				System.exit(0);
			}
			isEnvConfigured = false;
		}
		//if the metadata path is invalid exit
		if ( !isvalidPath(clientMetadataPath)) {
			System.err.println("invalid metadata file path-----");
			System.exit(0);
		}
		//STEP-2 get access token, using the client JSON
		String accessToken = null;
		if (!StringUtils.isBlank(clientMetadataPath) && isvalidPath(clientMetadataPath)) {
			OAuth2ClientCredentialsClientSDKService clientService = new OAuth2ClientCredentialsClientSDKService();
			accessToken = clientService.getAccessToken(new File(clientMetadataPath));
			if (StringUtils.isBlank(accessToken)) {
				System.err.println("Error occured while fetching Access token");
				return;
			}
		}
		System.out.println("----Access token is fetched successfully-----");
		//STEP-3 Test API with access token
		String protectedResourceEndpointURL = null;
		if (isEnvConfigured) {
			protectedResourceEndpointURL = (args.length >0)? args[0]:null;
		}else {
			protectedResourceEndpointURL = (args.length >1)? args[1]:null;
		}
		testProtectedResourceWithAccessToken(accessToken, protectedResourceEndpointURL);
	}

	/**
	 *  This method is used to invoke API with OAuth access token
	 *  By default, this method supports HTTP GET
	 * @param accessToken
	 * @param protectedResourceURL
	 */
	private static void testProtectedResourceWithAccessToken(final String accessToken, final String protectedResourceURL) {
		if (StringUtils.isBlank(accessToken) || StringUtils.isBlank(protectedResourceURL)) {
			logger.warn("API resource endpoint is--- "+protectedResourceURL);
			logger.warn("the Access token and Protected Resouce endpoint can't be null, thus exiting..");
			return;
		}
		HttpHeaders headers = new HttpHeaders();
		headers.add("Authorization", "Bearer "+accessToken);
		HttpEntity<String> entity = new HttpEntity<String>(headers);
		
		//We can use HTTPClient as well, for now using Spring's web template
		RestTemplate restTemplate = new RestTemplate();
		ResponseEntity<String> responseStringEntity = restTemplate.exchange(protectedResourceURL, HttpMethod.GET, entity, String.class);
		if(responseStringEntity != null) {
			String responseValue =  responseStringEntity.getBody();
			System.out.println("####------ API Response START ------####");
			System.out.println(responseValue);
			System.out.println("####------ API Response END ------####");
		}
	}

	private static boolean isvalidPath(String path) {
		if (path == null || path.trim().equals("")) {
			return false;
		}
		try {
			Paths.get(path);
		} catch (Exception e) {
			return false;
		}
		return true;
	}
}

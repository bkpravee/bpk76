package com.factset.oauth2.client.sdk;

import com.nimbusds.jose.JOSEException;
import com.nimbusds.jose.JWSAlgorithm;
import com.nimbusds.jose.JWSHeader;
import com.nimbusds.jose.crypto.RSASSASigner;
import com.nimbusds.jose.jwk.JWK;
import com.nimbusds.jose.jwk.KeyType;
import com.nimbusds.jose.jwk.RSAKey;
import com.nimbusds.jwt.JWTClaimsSet;
import com.nimbusds.jwt.SignedJWT;
import com.nimbusds.oauth2.sdk.ClientCredentialsGrant;
import com.nimbusds.oauth2.sdk.Scope;
import com.nimbusds.oauth2.sdk.TokenRequest;
import com.nimbusds.oauth2.sdk.TokenResponse;
import com.nimbusds.oauth2.sdk.auth.JWTAuthenticationClaimsSet;
import com.nimbusds.oauth2.sdk.auth.PrivateKeyJWT;
import com.nimbusds.oauth2.sdk.http.HTTPRequest;
import com.nimbusds.oauth2.sdk.id.Audience;
import com.nimbusds.oauth2.sdk.id.ClientID;
import com.nimbusds.oauth2.sdk.id.JWTID;
import com.nimbusds.oauth2.sdk.token.AccessToken;
import net.minidev.json.JSONObject;

import java.io.FileInputStream;
import java.io.IOException;
import java.net.MalformedURLException;
import java.net.URI;
import java.net.URISyntaxException;
import java.net.URL;
import java.security.KeyStore;
import java.security.KeyStoreException;
import java.security.NoSuchAlgorithmException;
import java.security.PrivateKey;
import java.security.PublicKey;
import java.security.cert.CertificateException;
import java.security.interfaces.RSAPrivateKey;
import java.security.interfaces.RSAPublicKey;
import java.text.ParseException;
import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.TimeUnit;

import org.apache.commons.lang3.StringUtils;

public class ClientCredentialsFlow {

   private final String tokenEndpointURL;
   private final String oAuthClientID;
   
      public  ClientCredentialsFlow(final String tokenEndpoint, final String clientID) {
    	
		if (StringUtils.isBlank(tokenEndpoint) || !isValidURL(tokenEndpoint)) {
    		throw new IllegalArgumentException("Invalid Token endpoint URL");
    	}
    	if (StringUtils.isBlank(clientID)) {
    		throw new IllegalArgumentException("Invalid clientID");
    	}
    	tokenEndpointURL = tokenEndpoint;
    	this.oAuthClientID = clientID;
    }

    private boolean isValidURL(final String endpointURL) {
       	if (endpointURL == null || endpointURL.trim().equals("")) {
    		return false;
    	}
       	try {
       		new URL(endpointURL).toURI();
       	} catch (final URISyntaxException e) {
       		return false;
       	} catch (final MalformedURLException e) {
      		return false;
  		}
       	return true;
    }

    public String getTokenWithKeyPair(final String keypair, final String[] audience, final String ... scopes) 
    		throws ParseException, URISyntaxException, JOSEException, IOException,com.nimbusds.oauth2.sdk.ParseException {
    	final RSAKey rsaJWK = this.rsaKeyFromKeyPair(keypair);
    	if (rsaJWK != null) {
        	final AccessToken accessToken = this.getAccessToken(rsaJWK, audience, scopes);
        	if (accessToken != null) {
        		return accessToken.getValue();
        	}
    	}
    	return null;
    }

    public String getTokenViaPEM(final String pemEncodedPrivateKey, final String[] audience, final String ... scopes) 
    		throws ParseException, URISyntaxException, JOSEException, IOException,com.nimbusds.oauth2.sdk.ParseException {
    	final RSAKey rsaJWK = this.rsaKeyFromPrivateKeyPem(pemEncodedPrivateKey);
    	if (rsaJWK != null) {
        	final AccessToken accessToken = this.getAccessToken(rsaJWK, audience, scopes);
        	if (accessToken != null) {
        		return accessToken.getValue();
        	}
    	}
    	return null;
    }
    public String getTokenUsingKeyStoreFile(final String keystorePath, final String alias, final String keystorePassword, 
    		final String[] audience, final String ... scopes) throws ParseException, URISyntaxException, JOSEException, 
    IOException,com.nimbusds.oauth2.sdk.ParseException, KeyStoreException, NoSuchAlgorithmException, CertificateException {
    	final RSAKey rsaJWK = this.rsaKeyFromKeyStore(keystorePath, alias, keystorePassword);
    	if (rsaJWK != null) {
        	final AccessToken accessToken = this.getAccessToken(rsaJWK, audience, scopes);
        	if (accessToken != null) {
        		return accessToken.getValue();
        	}
    	}
    	return null;
    }

    
    
    /**
     * This method loads RSAKey from JKS or PKSC12 keystore.
     * @param keystorePath
     * @param alias
     * @param keystorePassword
     * @return RSAKey
     * @throws JOSEException
     * @throws KeyStoreException
     * @throws NoSuchAlgorithmException
     * @throws CertificateException
     * @throws IOException
     */
    private RSAKey rsaKeyFromKeyStore(final String  keystorePath, final String alias, final String keystorePassword) throws JOSEException,
    KeyStoreException, NoSuchAlgorithmException, CertificateException, IOException {
    	if (keystorePath == null || alias == null || keystorePassword == null) {
    		throw new IllegalArgumentException("Keystore path, key alias or passphrase can't be null");
    	}
    	final char[] pwdArrray = keystorePassword.toCharArray();
    	//load the keystore
    	FileInputStream fis = null;
    	JWK rsaJWK = null;
    	try {
    		fis = new FileInputStream(keystorePath);
        	final KeyStore ks = KeyStore.getInstance(KeyStore.getDefaultType());
        	ks.load(fis, pwdArrray);
        	rsaJWK = JWK.load(ks, alias, pwdArrray);
      	} finally {
    		if (fis != null) {
    			fis.close();
    		}
    	}
      	if (rsaJWK == null || !rsaJWK.isPrivate()) {
    		throw new IllegalArgumentException("The pem file doesn't contain private key parts to be used for signing ");
    	}
    	if (rsaJWK instanceof RSAKey) {
    		return (RSAKey)rsaJWK;
    	}
		return null;

    }

     /**
     *  This method generates the RSA Key from public key and private key.
     * @param publicKey
     * @param privateKey
     * @return RSAKey
     * @throws JOSEException
     */
 
    private RSAKey rsaKeyFromKeys(final PublicKey publicKey, final PrivateKey privateKey) throws JOSEException {
    	if (publicKey == null || publicKey instanceof RSAPublicKey) {
    		throw new IllegalArgumentException("Invalid RSA public key");
    	}
    	if (privateKey == null || privateKey instanceof RSAPrivateKey) {
    		throw new IllegalArgumentException("Invalid RSA public key");
    	}
    	final RSAKey rasJWKKey = new RSAKey.Builder((RSAPublicKey)publicKey).privateKey(privateKey).build();
    	if (rasJWKKey == null || !rasJWKKey.isPrivate() || rasJWKKey.getKeyType() != KeyType.RSA) {
    		throw new IllegalArgumentException("The JWK doesn't contain private key to sign the JWT ");
    	}
        return rasJWKKey;
    }

    /**
     * This method to be used when using private key PEM.
     * @param pemEncodedPrivateKey
     * @return RSAKey
     * @throws JOSEException
     */
    private RSAKey rsaKeyFromPrivateKeyPem(final String pemEncodedPrivateKey) throws JOSEException {
    	if (pemEncodedPrivateKey == null || pemEncodedPrivateKey.trim().equals("")) {
    		throw new IllegalArgumentException("Invalid private key pem");
    	}
    	final JWK rsaJWK = JWK.parseFromPEMEncodedObjects(pemEncodedPrivateKey);
    	if (rsaJWK == null || !rsaJWK.isPrivate()) {
    		throw new IllegalArgumentException("The pem file doesn't contain private key parts to be used for signing ");
    	}
    	if (rsaJWK instanceof RSAKey) {
    		return (RSAKey)rsaJWK;
    	}
    	return null;
    }

    private RSAKey rsaKeyFromKeyPair(final String keypair) throws JOSEException, ParseException {
    	if (keypair == null || keypair.trim().equals("")) {
    		throw new IllegalArgumentException("Invalid keypair");
    	}
    	final RSAKey jwk = RSAKey.parse(keypair);
    	if (jwk == null || !jwk.isPrivate()) {
    		throw new IllegalArgumentException("The kyepair provided doesn't have the private key to sign the JWT");
    	}
    	return jwk;
     }

   
    private AccessToken getAccessToken(final RSAKey rsaJWK,final String[] audience, final String ... scopes) 
    		throws ParseException, com.nimbusds.oauth2.sdk.ParseException, IOException, URISyntaxException, JOSEException {
    	final TokenRequest tokenRequest = new TokenRequest(
    			new URI(tokenEndpointURL),
    			new PrivateKeyJWT(createSignedJWT(rsaJWK, audience)),
    			new ClientCredentialsGrant(),
    			new Scope(scopes));

    	//printTokenRequest(tokenRequest);

    	final TokenResponse tokenResponse = TokenResponse.parse(tokenRequest.toHTTPRequest().send());

    	if (!tokenResponse.indicatesSuccess()) {
    		System.out.format("Error: %s%n", tokenResponse.toErrorResponse().getErrorObject());
    		System.out.format("Response status code : %s%n", tokenResponse.toHTTPResponse().getStatusCode());

    		return null;
    	}

    	final AccessToken accessToken = tokenResponse.toSuccessResponse().getTokens().getAccessToken();
    	//printAccessToken(accessToken);
    	return accessToken;

    }

    private void printAccessToken(final AccessToken accessToken) throws ParseException {
        System.out.format("Received Access Token: %s%n", accessToken.getValue());

        final SignedJWT accessTokenSignedJWT = SignedJWT.parse(accessToken.getValue());

        printJSONObject(accessTokenSignedJWT.getHeader().toJSONObject(), "Header");

        printJSONObject(accessTokenSignedJWT.getPayload().toJSONObject(), "Payload");

        printClaimsSet(accessTokenSignedJWT.getJWTClaimsSet());

        printSignature(accessTokenSignedJWT.getSignature().decode());
    }

    private void printJSONObject(final JSONObject jsonObject, final String description) {
        System.out.format("%s: %s%n", description, jsonObject);
        printEntrySet(jsonObject.entrySet());
    }

    private void printClaimsSet(final JWTClaimsSet claimsSet) {
        System.out.println("ClaimsSet:");
        printEntrySet(claimsSet.getClaims().entrySet());
    }

    private void printEntrySet(final Set<Map.Entry<String, Object>> entrySet) {
        for (final Map.Entry<String, Object> entry : entrySet) {
            System.out.format("\t%s = %s%n", entry.getKey(), entry.getValue());
        }
    }

    private void printSignature(final byte[] signature) {
        final StringBuilder sb = new StringBuilder("Signature: ");
        for (int i = 0; i < signature.length; ++i) {
            if (i > 0) {
                sb.append(',');
            }
            sb.append(String.format("%02X", signature[i]));
        }
        System.out.println(sb);
    }

    private void printTokenRequest(final TokenRequest request) {
        final HTTPRequest httpRequest = request.toHTTPRequest();
        final URL url = httpRequest.getURL();
        System.out.format("%s %s HTTP/1.1%n", httpRequest.getMethod(), url.getPath());
        System.out.format("Host: %s%n", url.getHost());
        System.out.println();
        boolean first = true;
        for (final Map.Entry<String, List<String>> entry : request.toHTTPRequest().getQueryParameters().entrySet()) {
            System.out.format("%s%s=%s%n", first ? "" : "&", entry.getKey(), entry.getValue().get(0));
            first = false;
        }
        System.out.println();
    }
    private SignedJWT createSignedJWT(final RSAKey jwk, final String... audience) throws ParseException, 
    JOSEException {
       if (audience == null || audience.length == 0) {
    	   System.out.println("audience can't be empty, Audience must include Authorization endpoint or token endpoint or both");
   		throw new IllegalArgumentException("Invalid Audience, Audience must include Authorization endpoint or token endpoint or both");
      }
        final RSASSASigner signer = new RSASSASigner(jwk);

        final JWSHeader header = new JWSHeader.Builder(JWSAlgorithm.RS256).keyID(jwk.getKeyID()).build();

        final ClientID clientID = new ClientID(this.oAuthClientID);

        final List<Audience> aud = Audience.create(audience);

        final long now = (new Date()).getTime();
        final Date exp = new Date(now + TimeUnit.MINUTES.toMillis(5));
        final Date nbf = new Date(now - TimeUnit.SECONDS.toMillis(5));
        final Date iat = new Date(now);

        final JWTID jti = new JWTID();

        final JWTClaimsSet payload = new JWTAuthenticationClaimsSet(clientID, aud, exp, nbf, iat, jti)
                .toJWTClaimsSet();

        final SignedJWT signedJWT = new SignedJWT(header, payload);

        signedJWT.sign(signer);

        return signedJWT;
    }

    public static void main(final String... args) throws ParseException, URISyntaxException, JOSEException, IOException,
            com.nimbusds.oauth2.sdk.ParseException {
       //new ClientCredentialsFlow().launch();
    }
}

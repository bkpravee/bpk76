/**
 * 
 */
package com.factset.oauth2.client.sdk.model;

import com.fasterxml.jackson.annotation.JsonProperty;

/**
 * @author pbamini
 *
 */
public class AsymmetricKeyPEM {

	@JsonProperty ("keyId")
	private String keyId;
	@JsonProperty("public")
	private String publicKey;
	@JsonProperty("private")
	private String privateKey;
	
	public String getKeyId() {
		return keyId;
	}
	public void setKeyId(String keyId) {
		this.keyId = keyId;
	}
	public String getPublicKey() {
		return publicKey;
	}
	public void setPublicKey(String publicKey) {
		this.publicKey = publicKey;
	}
	public String getPrivateKey() {
		return privateKey;
	}
	public void setPrivateKey(String privateKey) {
		this.privateKey = privateKey;
	}

}

/**
 * 
 */
package com.factset.oauth2.client.sdk.service;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.URISyntaxException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.List;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.factset.oauth2.client.sdk.ClientCredentialsFlow;
import com.factset.oauth2.client.sdk.model.AsymmetricKeyPEM;
import com.factset.oauth2.client.sdk.model.OAuthClientRegistrationInfo;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.nimbusds.jose.JOSEException;
import com.nimbusds.oauth2.sdk.ParseException;

/**
 * @author pbamini
 *
 */
public class OAuth2ClientCredentialsClientSDKService {

	private final Logger logger = LoggerFactory.getLogger(OAuth2ClientCredentialsClientSDKService.class);
	
	private  OAuthClientRegistrationInfo parseClientMetadataOAuthClient(File clientMetadataFile) throws IOException {
		if (clientMetadataFile == null) {
			logger.warn("file can't be null");
			return null;
		}
		try {
			logger.debug("parsing client metadata JSON");
			ObjectMapper mapper = new ObjectMapper();
			mapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
			InputStreamReader isr = new InputStreamReader(new FileInputStream(clientMetadataFile), StandardCharsets.UTF_8);
			OAuthClientRegistrationInfo client =  mapper.readValue(isr, OAuthClientRegistrationInfo.class);
			return client;
		} catch (IOException e) {
			logger.error("Invalid JSON metadata file");
			throw e;
		}
	}

	/**
	 * This method reads the client metadata file and uses the metadata to fetch access token using client credentials grant flow
	 * 
	 * @param clientMetadataFile
	 * @return Access Token 
	 * 
	 * @throws IOException
	 * @throws ParseException
	 * @throws java.text.ParseException
	 * @throws URISyntaxException
	 * @throws JOSEException
	 */
	public String getAccessToken(File clientMetadataFile) throws IOException, ParseException, java.text.ParseException, URISyntaxException, JOSEException {
		logger.debug("##generating access token via client metadata file");
		OAuthClientRegistrationInfo client = this.parseClientMetadataOAuthClient(clientMetadataFile);
		if(client == null || client.getClientID() == null) {
			logger.error("Invalid client metadata file");
			throw new IOException();
		}
		String pemContent = null;
		String privateKeyPath = client.getPrivateKeyPemFilePath();
		if (StringUtils.isBlank(privateKeyPath) || !isvalidPath(privateKeyPath)) {
			if (client.getPems() != null) {
				AsymmetricKeyPEM keypair = client.getPems().get(0);
				if (keypair != null) {
					pemContent = client.getPems().get(0).getPrivateKey();
				}
			}
		} else {
			//if private key path is present then always read key from file path
			pemContent = new String(Files.readAllBytes(new File(client.getPrivateKeyPemFilePath()).toPath()), StandardCharsets.UTF_8);
		}
		if (StringUtils.isBlank(pemContent)) {
			logger.warn("the signing key is required to sign client assertion, it is not present. thus exiting...");
			return null;
		}
		ClientCredentialsFlow clientCredentialSDK = new ClientCredentialsFlow(client.getTokenEndpoint(), client.getClientID());
		List<String> scopes = client.getScopes();
		String[] oauthScopes = null;
		if (scopes == null || scopes.isEmpty()) {
			oauthScopes = new String[0];
		} else {
			oauthScopes = client.getScopes().toArray(new String[0]);
		}
		return clientCredentialSDK.getTokenViaPEM(pemContent,new String[]{client.getTokenEndpoint()}, oauthScopes);
	}
	
	private boolean isvalidPath(String path) {
		if (path == null || path.trim().equals("")) {
			return false;
		}
		try {
			Paths.get(path);
		} catch (Exception e) {
			return false;
		}
		return true;
	}
}

/**
 * 
 */
package com.factset.oauth2.client.sdk.model;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonProperty;

/**
 * @author pbamini
 *
 */
public class OAuthClientRegistrationInfo {
	
	@JsonProperty("authorization_endpoint")
	private String authorizationEndpoint;
	
	@JsonProperty("token_endpoint")
	private String tokenEndpoint;
	
	@JsonProperty("scopes_supported")
	private List<String> scopes;
	
	@JsonProperty("clientId")
	private String clientID;
	
	@JsonProperty("name")
	private String clientName;
	
	@JsonProperty("clientAuthType")
	private String clientAuthenticationType;
	
	@JsonProperty("pems")
	private List<AsymmetricKeyPEM> pems;

	@JsonProperty("grant_types_supported")
	private List<String> grant_types_supported;
	
	@JsonProperty("redirect_uris")
	private List<String> redirectUris;
	
	@JsonProperty("private_key_pem_path")
	private String privateKeyPemFilePath;


	public String getClientID() {
		return clientID;
	}
	public void setClientID(String clientID) {
		this.clientID = clientID;
	}
	public String getClientName() {
		return clientName;
	}
	public void setClientName(String clientName) {
		this.clientName = clientName;
	}
	public String getClientAuthenticationType() {
		return clientAuthenticationType;
	}
	public void setClientAuthenticationType(String clientAuthenticationType) {
		this.clientAuthenticationType = clientAuthenticationType;
	}
	public List<AsymmetricKeyPEM> getPems() {
		return pems;
	}
	public void setPems(List<AsymmetricKeyPEM> pems) {
		this.pems = pems;
	}
	public String getAuthorizationEndpoint() {
		return authorizationEndpoint;
	}
	public void setAuthorizationEndpoint(String authorizationEndpoint) {
		this.authorizationEndpoint = authorizationEndpoint;
	}
	public String getTokenEndpoint() {
		return tokenEndpoint;
	}
	public void setTokenEndpoint(String tokenEndpoint) {
		this.tokenEndpoint = tokenEndpoint;
	}
	public List<String> getScopes() {
		return scopes;
	}
	public void setScopes(List<String> scopes) {
		this.scopes = scopes;
	}
	public List<String> getGrant_types_supported() {
		return grant_types_supported;
	}
	public void setGrant_types_supported(List<String> grant_types_supported) {
		this.grant_types_supported = grant_types_supported;
	}
	public List<String> getRedirectUris() {
		return redirectUris;
	}
	public void setRedirectUris(List<String> redirectUris) {
		this.redirectUris = redirectUris;
	}
	public String getPrivateKeyPemFilePath() {
		return privateKeyPemFilePath;
	}
	public void setPrivateKeyPemFilePath(String privateKeyPemFilePath) {
		this.privateKeyPemFilePath = privateKeyPemFilePath;
	}
}
